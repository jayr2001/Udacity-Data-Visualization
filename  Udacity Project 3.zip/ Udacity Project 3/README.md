
# (Dataset Exploration Title)
## By: BENJAMIN JUMA


## Dataset


In this project, I am using the Loan Data set  from Prosper. The data set contains 113937 loans with 81 variables on each loan. Some of these variables are loan amount, borrower rate (interest rate), current loan status, borrower income, occupation, recommendation, employments status and many others. Out of these 81 variables, i selected 25 variables of interset which i am using for my visualization and exploration. After subsetting the data, i performed some data wrangling to clean up the data, some of which entailed imputing missing values for various columns, correcting wrong data types in some variables. I also did some feature engineering where i created new variables from the existing variables so as to aid in giving better insights to my research questions.

## Summary of Findings

After exploration of the data, i came up with the following insights/findings, some of which i would like to bring in to the explanotary presentataion phase:
On the univariate distribution of variables; the distribution of loan satus variable indicates that current loans are the most frequent in the data with over fifty thousand counts, followed by loans which are already completed, with almost fourty thousand counts. Chargeoff and defaulted loans comes next respectively. Past due and cancelled loans are the least frequent with nearly less than ten thouand counts.

The Prosper score variable takes intergarl values beetween 1 and 11, and its distribution appears to be normaly distributed, with most and least frequent scores being 4 and 1 respectively.
Most of the loans had a duration of 36 months while quite a few of them had a duration of 12 months.

Most of the prospers were employed at the time the listing was posted, followed by full time enployers. Merely less that ten thousand of the prospers were unemployed, part time employed or retired altogather at tthe time they posted the listing.

More than half of the borrowers had a morgage on their credit profile or  provided documentation confirming that they wer homeowners as can be seen in the above donut chart.

At the time of listing, most of the borrowers were having an income ranging from  25000  to  49999  , followed by those whose income ranges from  50000  to  74999  US dollars. Merely less than five thousand porspers were unemployed or earned no income altogather.

Many borrowers were from the state of California during the time of listing while the state of Nevada had the least borrowers as it has the lowest number of counts.

The total trades variable was found to be positively skewed. In adition, there was no borrower who had conducted more than eighty trades.
Loan original amount varibale looks somewhat skewed to the left. There are regular spikes in the plot after a certain interval. This may be suggesting possible bimodal or trimodal distribution of this variable.

I found that there was a positive linear correlation between prosper rating and loan original amount. This implies that loan amount given to the borrower tend to increase as the rating increase.

From the positional encodings in the multivariate plot to depict the relationship between the three variables,we can see that there is a fair correlation between thhe two numerical variables (LoanOriginalAmount and Monthly loan payment). In addition, i found that individuals who are in the category of home owners are quite smaller than those who are not home owners in terms of numeric variable (monthly loan payment).

From the multivariate scatter plot i made, i found that there exist a positive linear relationship between the two numeric variables i.e, MonthlyLoanPayment and LoanOriginalAmount. Futhermore, the third categorical variable (employment status) is also directly positively  correlated with both of the numerical variables.

Finally, as my main response variable of interest was the original amount of loan borrowed, i considered the correlation between this variable with other variables. We can clearly see that borrower APR, borrower Rate,lender yield,listing category, currently in group and recommendation variables are weakly and negatively correlated with the original loan amount given to a prosper as they have a negative correlation coefficiennt which are below -0.5. On the other hand, term, prosper rating,prosper score,is borrower home owner,employment status duration,total trades,stated monthly income and total prosper loans are weakly but positively correlated with the original amount of loan a prosper can be given as their correlation coefficients are positive but below 0.5 threshhold. Finally, monthly loan payment variable is very strongly and positively correalated with the original loan amount that a prosper can be given as it has a correlatin coefficient of 0.93.

​
## Key Insights for Presentation

I am further exploring the distribution of key variables of interest in the dataset. Furthermore, i am going  to polish my visualizations on the relationship between various variables and the response variable (loan original amount), including borrowers interest rate, stated monthly income and monthly loan payment. I have selected thes variables over the others as i have noticed that there exist a certain trend between them and the loan original amount.